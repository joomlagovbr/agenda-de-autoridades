DROP TABLE IF EXISTS `#__agendadirigentes_agendaalterada`;
DROP TABLE IF EXISTS `#__agendadirigentes_dirigentes`;
DROP TABLE IF EXISTS `#__agendadirigentes_dirigentes_compromissos`;
DROP TABLE IF EXISTS `#__agendadirigentes_cargos`;
DROP TABLE IF EXISTS `#__agendadirigentes_compromissos`;