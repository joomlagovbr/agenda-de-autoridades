<div class="content-header-options-1 row-fluid">		
	<div class="documentByLine span4">&nbsp;</div>
	<div class="btns-social-like span8">
		{MODULE}
	</div>			
</div>